import java.util.Scanner;//Used to read user input
import java.util.Random;//Used to generate random number of people

public class StaticFoodServing extends DynamicFoodServing{   //inheritance
    public static void main(String[] args){
        // Create Random object to simulate current number of people
        Random rand =new Random();
        Robot robot = new Robot("20806655", "Junhao Li");// Create a Robot object with ID and name
        Restrictedspots[] spots=new Restrictedspots[5];// Create an array to store 5 dining spots
        // Initialize each dining spot (ID, Name, Area, Average Time)
        spots[0]=new Restrictedspots(1,"Dining Foyer",60,20);
        spots[1]=new Restrictedspots(2,"Main Dining Hall",100,40);
        spots[2]=new Restrictedspots(3,"Dining Terrace one",80,30);
        spots[3]=new Restrictedspots(4,"Dining Terrace Two",70,25);
        spots[4]=new Restrictedspots(5,"Family Dining Terrace",90,35);
        
        System.out.println("Student: "+robot.getRobotname()+"(ID: "+robot.getRobotid()+")");//display robot id and name
        Scanner check =new Scanner(System.in);// Create Scanner object for user input
        boolean condition = true;//Loop control variable
        do {  //do-while loop ensures the program runs at least once
            String answer = "";//Store user's waiting decision
            System.out.println("\n===== Select a Dining Spot =====");
            for(int i=0;i<spots.length;i++){    //Use for loop to display all dining spots
            spots[i].Display();
            }
            System.out.println("Please select a dining spot:");
            
            int choice=check.nextInt();// Get user choice
            
            Restrictedspots selected=null;
            switch (choice) {  // Use switch to assign selected spot
                case 1:
                    selected=spots[0];
                    break;
                case 2:
                    selected=spots[1];
                    break;
                case 3:
                    selected=spots[2];
                    break;
                case 4:
                    selected=spots[3];
                    break;
                case 5:
                    selected=spots[4];
                    break;
            
                default:
                    System.out.println("Invalid choice.Please select a number between 1 and 5.");
                    continue;
            }
             System.out.println("You selected: " + selected.SpotName); // Display selected spot name
             int currentpeople= rand.nextInt(selected.Capacity+1);// Generate random current number of people (0 to capacity)
            System.out.println("Current people: " + currentpeople);// Check if the spot is full (Problem I core logic)
            if (currentpeople<selected.Capacity) { // Not full → allow entry
            System.out.println("You can enter "+selected.SpotName +".Enjoy your meal!");
            // Input distances from four directions (Dynamic distancing)
            System.out.println("Enter LEFT distance: ");
                double left = check.nextDouble();

                System.out.println("Enter RIGHT distance: ");
                double right = check.nextDouble();

                System.out.println("Enter FRONT distance: ");
                double front = check.nextDouble();

                System.out.println("Enter BACK distance: ");
                double back = check.nextDouble();
                DynamicFoodServing model = new DynamicFoodServing();// Create DynamicFoodServing object
                // Call method to check dynamic distancing (Problem II)
                model.Checkdistance(left, right, front, back, robot.getRobotid(), robot.getRobotname(), selected.SpotID, selected.SpotName);
                condition = false;// End process and exit loop
                continue;

            
            }else{  // If full → show message
            System.out.println(selected.SpotName + " is FULL! Maximum capacity: " + selected.Capacity);
            System.out.println("Average waiting time: " + selected.AverageTime + " minutes");
            System.out.print("Do you want to wait? (yes/no): ");
            answer = check.next();
            }    //read the next word

    
                if (answer.equalsIgnoreCase("yes")) {          //compar yes ingoring uppercase and lowercase
            System.out.println("You waited. Now you can enter!");          // Check if user chooses to wait
        
                }else {   // If not waiting → select another spot
            System.out.println("Please select another spot.");
            continue;  
                }
        }while (condition);
         check.close();    // Close Scanner 
    }
}
        
        
        
        
        

    
    


