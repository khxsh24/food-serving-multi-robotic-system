public class Restrictedspots {
    int SpotID;//variables
    String SpotName;
    int  Capacity;//Spot Maximum Capacity
    double SpotArea;
    double AverageTime;//Spot Permitted Average Time per robo
    public Restrictedspots(int SpotID,String SpotName,double SpotArea,double AverageTime){
        this.SpotID = SpotID;//Store the value of the parameter id in the spotID variable
        this.SpotName = SpotName;
        this.SpotArea = SpotArea;
        this.AverageTime = AverageTime;
        this.Capacity = CalculateCapacity();

    }
public int CalculateCapacity(){
    return (int)(SpotArea/2);//Assming each robot occupies 2 square meters of space

}
public void Display(){
    System.out.println(SpotID+"-"+SpotName+"-"+Capacity);
}    
}
