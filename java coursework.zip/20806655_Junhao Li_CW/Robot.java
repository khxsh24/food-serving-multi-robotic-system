public class Robot{
    private String Robotid;//protect data by making it private
    private String Robotname;
    public Robot(String id,String name){ //Constructor to initialize Robot object
        // Assign values to class fields
        this.Robotid =id;
        this.Robotname =name;
    }


public String getRobotid(){
    return Robotid;
}
public String getRobotname(){
    return Robotname;
}
}//turn data access into controlled access,encapsulation
