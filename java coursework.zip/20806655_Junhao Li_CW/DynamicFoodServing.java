import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class DynamicFoodServing{
     // - Conditional decision-making (if-else logic)
    public void Checkdistance(double distance,String direction){  // Check distance for a single direction
        if (distance<1.0){
            if (distance<0.5) {
                System.out.println("❗ Move 1m away from " + direction);
            } else {
                System.out.println("⚠ Move 0.5m away from " + direction);
            }
            

        }else{  // Safe condition: no action required
            System.out.println(direction + ": Safe ✓");
        }
    }   //method overloading
    // =========================================================
    // METHOD 2 (OVERLOADED METHOD)
    // Purpose:
    // This method evaluates safety in four directions
    // (LEFT, RIGHT, FRONT, BACK) and generates a report
    // if any unsafe condition is detected.
    //
    // Concept Demonstrated:
    // - Method Overloading
    // - Code reuse (calling another overloaded method)
    // - Logical OR condition checking
    // - Real-time system logging using date/time API
    // =========================================================
    public void Checkdistance(double left,double right,double front,double back,String Robotid,String Robotname,int SpotID,String SpotName){
        boolean hasContact = (left < 1.0 || right < 1.0 || front < 1.0 || back < 1.0); // Determine whether ANY direction violates safety threshold
        Checkdistance(left,"LEFT");
        Checkdistance(right,"RIGHT");
        Checkdistance(front,"FRONT");
        Checkdistance(back,"BACK");
        if (hasContact){

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
             // =========================
            // REPORT OUTPUT SECTION
            // =========================
            System.out.println("\n=== CASUAL CONTACT REPORT ===");
            System.out.println("Robot ID: " + Robotid);
            System.out.println("Robot Name: " + Robotname);
            System.out.println("Spot ID: " + SpotID);
            System.out.println("Spot Name: " + SpotName);
            System.out.println("Date: " + now.format(dateFormatter));
            System.out.println("Time: " + now.format(timeFormatter));
            System.out.println("Contact Status: Casual Contact");
            System.out.println("==============================");
        }else{  // Fully safe scenario (no violations in any direction)
            System.out.println("You are safe in dynamic distancing!");
        }



        

    }

}
